import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ArrowRight, Eye, EyeOff } from 'lucide-react'
import { validateAuth } from '../utils/authValidation.js'
import LanguageSwitcher from './LanguageSwitcher.jsx'
import BrandLogo from './BrandLogo.jsx'
import RegistrationForm from './RegistrationForm.jsx'
import PatientOnboarding from './PatientOnboarding.jsx'
import { patientApi, authenticatedPatientDestination, actionErrorKey } from '../services/patientApi.js'
import { EmailVerification, PasswordRecovery } from './EmailAuthentication.jsx'
import useFormAction from '../utils/useFormAction.js'
import './AuthModal.css'

function AuthForm({ mode }) {
  const { t } = useTranslation(['auth', 'common'])
  const [values, setValues] = useState({ email: '', password: '' })
  const [visible, setVisible] = useState({})
  const fields = ['email', 'password']
  const { errors, setErrors, clearField, pending, failure, submit } = useFormAction({
    values, fields, validate: details => validateAuth(details, 'login'),
    action: (details, options) => patientApi.login({ email: details.email.trim(), password: details.password }, options),
    onSuccess: async (_result, options) => {
      const destination = await authenticatedPatientDestination(options)
      if (destination === '#/login') throw new Error('Authentication was not confirmed')
      window.location.hash = destination.slice(1)
    },
  })

  function updateValue(field, value) {
    setValues(previous => ({ ...previous, [field]: value }))
    clearField(field)
  }

  return <>
    <div className="eyebrow">{t(`auth:${mode}.label`)}</div>
    <h1 id="auth-heading" tabIndex={-1}>{t(`auth:${mode}.heading`)}</h1>
    <p id="auth-description">{t(`auth:${mode}.description`)}</p>
    <form noValidate onSubmit={submit} aria-busy={pending}>
      {fields.map((field, index) => {
        const password = field === 'password' || field === 'confirmPassword'
        const id = `auth-${field}`
        const errorId = `${id}-error`
        const visibilityKey = field === 'confirmPassword' ? 'ConfirmPassword' : 'Password'
        return <div className="auth-field" key={field}>
          <label htmlFor={id}>{t(`auth:fields.${field}`)}</label>
          <div className={password ? 'auth-password' : undefined}>
            <input
              id={id}
              name={field}
              type={password ? (visible[field] ? 'text' : 'password') : field === 'email' ? 'email' : 'text'}
              value={values[field]}
              onChange={event => updateValue(field, event.target.value)}
              onBlur={() => setErrors(previous => ({ ...previous, [field]: validateAuth(values, mode)[field] }))}
              required
              disabled={pending}
              autoFocus={index === 0}
              autoComplete={field === 'email' ? 'username' : 'current-password'}
              dir={field === 'email' ? 'ltr' : undefined}
              lang={field === 'email' ? 'en' : undefined}
              placeholder={t(`auth:fields.${field}`)}
              aria-invalid={Boolean(errors[field])}
              aria-describedby={errors[field] ? errorId : undefined}
              autoCapitalize={field === 'name' ? 'words' : 'none'}
              spellCheck={field === 'name'}
            />
            {password && <button
              className="auth-password-toggle" disabled={pending}
              type="button"
              aria-label={t(`auth:${visible[field] ? 'hide' : 'show'}${visibilityKey}`)}
              aria-pressed={Boolean(visible[field])}
              aria-controls={id}
              onClick={() => setVisible(previous => ({ ...previous, [field]: !previous[field] }))}
            >{visible[field] ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}</button>}
          </div>
          {errors[field] && <span className="auth-error" id={errorId} role="alert">{t(`auth:errors.${errors[field]}`)}</span>}
        </div>
      })}
      <button className="button button-primary auth-submit" type="submit" disabled={pending}>
        {t(pending ? 'auth:actions.signingIn' : `auth:${mode}.submit`)}<ArrowRight size={17} aria-hidden="true" />
      </button>
      {failure && <p className="auth-error" role="alert">{t(actionErrorKey(failure, 'errors.loginUnavailable'))}</p>}
    </form>
    <a className="auth-switch" href="#/forgot-password">{t('auth:recovery.forgotLink')}</a>
    <a className="auth-switch" href="#/signup">
      {t(`auth:${mode}.switch`)}
    </a>
  </>
}

export default function AuthPage({ mode, step = 'account', registration, onRegistered }) {
  const { t, i18n } = useTranslation(['auth', 'common'])
  useEffect(() => {
    document.title = 'Smart-LIMS'
    document.getElementById('auth-heading')?.focus()
    return () => { document.title = 'Smart-LIMS' }
  }, [mode, step, t, i18n.resolvedLanguage])
  return <AuthLayout mode={mode}>
    {step === 'verification' ? <EmailVerification registration={registration} /> : step === 'forgotPassword' || step === 'resetPassword' ? <PasswordRecovery reset={step === 'resetPassword'} /> : step !== 'account' ? <PatientOnboarding step={step} /> : mode === 'login' ? <AuthForm mode={mode} /> : <RegistrationForm onRegistered={onRegistered} />}
  </AuthLayout>
}

export function AuthLayout({ mode = 'login', children }) {
  const { t, i18n } = useTranslation(['auth', 'common'])
  const cardRef = useRef(null)
  useLayoutEffect(() => {
    const card = cardRef.current
    const heading = card.querySelector('#auth-heading')
    const tools = card.querySelector('.auth-brand-tools')
    const logo = card.querySelector('.auth-logo')
    if (!heading) return
    let disposed = false
    const alignLogo = () => {
      if (disposed) return
      // Visible artwork starts at row 88 in the unchanged 1774px-wide PNG.
      const transparentInset = logo.getBoundingClientRect().width * 88 / 1774
      const offset = heading.getBoundingClientRect().top - tools.getBoundingClientRect().top - transparentInset
      card.style.setProperty('--auth-logo-heading-offset', `${offset}px`)
    }
    const observer = new ResizeObserver(alignLogo)
    for (const element of [card, heading, tools]) observer.observe(element)
    logo.addEventListener('load', alignLogo)
    void document.fonts.ready.then(alignLogo)
    alignLogo()
    return () => { disposed = true; observer.disconnect(); logo.removeEventListener('load', alignLogo) }
  }, [children, i18n.resolvedLanguage])
  return <div className="patient-auth">
    <a className="auth-skip" href="#auth-content" onClick={event => { event.preventDefault(); document.getElementById('auth-heading')?.focus() }}>{t('auth:page.skip')}</a>
    <main id="auth-content" className="auth-content">
      <div className="auth-card" ref={cardRef}>
        <div className="auth-layout">
          <aside className="auth-branding">
            <div className="auth-light-ribbons" aria-hidden="true">
              {Array.from({ length: 5 }, (_, index) => <span key={index} />)}
            </div>
            <div className="auth-brand-tools">
              <a href="#home" className="auth-logo-link" aria-label={t('common:homeLabel')}><BrandLogo alt="SmartLIMS" className="auth-logo" /></a>
            </div>
            <div className="auth-brand-copy">
              <span className="auth-brand-rule" aria-hidden="true" /><p>{t('auth:page.infoHeading')}</p>
            </div>
            <LanguageSwitcher />
          </aside>

          <section className="auth-form-panel" aria-labelledby="auth-heading">
            {children}
          </section>
        </div>
            <nav className="auth-tabs" aria-label={t('common:mainNavigation')} data-mode={mode}>
              <a href="#/login" aria-current={mode === 'login' ? 'page' : undefined}>{t('auth:tabs.login')}</a>
              <a href="#/signup" aria-current={mode === 'signup' ? 'page' : undefined}>{t('auth:tabs.signup')}</a>
            </nav>
      </div>
    </main>
  </div>
}
