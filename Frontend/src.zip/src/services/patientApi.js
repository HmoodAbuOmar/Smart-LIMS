// Frontend adapter boundary. Replace the transport here only when real API
// contracts exist; never infer endpoints or return simulated success/session data.
const operations = new Set(['registerAccount', 'login', 'patientAccess', 'createFile', 'linkFile', 'verifyEmail', 'resendVerification', 'verificationStatus', 'requestPasswordReset', 'resetPassword'])

export async function requestPatientOperation(operation, payload, { signal } = {}) {
  signal?.throwIfAborted()
  if (!operations.has(operation)) throw new Error('Unknown patient operation')
  // payload must go directly to the future transport, never storage or logging.
  void payload
  const error = new Error('Patient service transport is not configured')
  error.code = 'SERVICE_UNAVAILABLE'
  throw error
}

export const patientApi = Object.freeze({
  registerAccount: (payload, options) => requestPatientOperation('registerAccount', payload, options),
  login: (payload, options) => requestPatientOperation('login', payload, options),
  getAccess: options => requestPatientOperation('patientAccess', undefined, options),
  createFile: (payload, options) => requestPatientOperation('createFile', payload, options),
  linkFile: (payload, options) => requestPatientOperation('linkFile', payload, options),
  verifyEmail: (payload, options) => requestPatientOperation('verifyEmail', payload, options),
  resendVerification: (payload, options) => requestPatientOperation('resendVerification', payload, options),
  verificationStatus: (payload, options) => requestPatientOperation('verificationStatus', payload, options),
  requestPasswordReset: (payload, options) => requestPatientOperation('requestPasswordReset', payload, options),
  resetPassword: (payload, options) => requestPatientOperation('resetPassword', payload, options),
})

// These paths become authorized destinations only after a trusted server response.
export function patientDestination(access) {
  if (access?.authenticated !== true) return '#/login'
  if (access.role !== 'patient') return null // Preserve real role routing when supplied.
  if (access.emailVerified !== true) return '#/verify-email'
  if (access.hasLinkedMedicalFile === true) return '#/patient/dashboard'
  if (access.hasLinkedMedicalFile === false) return '#/patient/file'
  return null
}

// Never render arbitrary server exception text. Adapter errors use these normalized codes.
export function actionErrorKey(code, fallback) {
  const keys = { INVALID_CREDENTIALS: 'errors.invalidCredentials', RATE_LIMITED: 'errors.rateLimited', EMAIL_NOT_VERIFIED: 'errors.emailNotVerified', TOKEN_EXPIRED: 'errors.tokenExpired', TOKEN_INVALID: 'errors.tokenInvalid', SESSION_EXPIRED: 'errors.sessionExpired' }
  return typeof code === 'string' && Object.hasOwn(keys, code) ? keys[code] : fallback
}

export async function authenticatedPatientDestination(options) {
  const destination = patientDestination(await patientApi.getAccess(options))
  options?.signal?.throwIfAborted()
  if (!destination) throw new Error('Authoritative patient access is required')
  return destination
}
