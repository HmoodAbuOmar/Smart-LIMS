import { useEffect, useId, useRef, useState } from 'react'
import { Building2, CheckCircle2, Clock, CreditCard, Plus, Trash2 } from 'lucide-react'
import { bookingDraftError, checkoutDraft, selectedBookingTests } from './bookingModel.js'
import { dateAtOffset, timeSlots, totalPrice, validSlot } from './portalModel.js'
import './BookingFlow.css'
import HostedCardForm from './HostedCardForm.jsx'
import { validReceiptEmail } from '../services/hostedPayment.js'


export function BookingSummary({ api, draft, ui, removable = false, finalReview = false }) {
  const { state, t, date, money, local, dispatch } = api
  const ids = draft.tests || selectedBookingTests(state, draft)
  return <section className="booking-summary">{finalReview && <dl className="booking-summary-date"><dt>{t('name')}</dt><dd>{api.name || state.profile.name}</dd><dt>{t('payment')}</dt><dd>{t(draft.method)}</dd></dl>}<h2>{t('bookingSelected')}</h2>{ids.length ? <ul>{ids.map(id => { const test = state.tests.find(test => test.id === id); return <li key={id}><span>{local(test.name)}</span><strong>{money(test.price)}</strong>{removable && state.cart.includes(id) && <button type="button" className="portal-danger-icon" aria-label={`${t('remove')} ${local(test.name)}`} onClick={() => dispatch({ type: 'REMOVE', id })}><Trash2 size={16} /></button>}</li> })}</ul> : <p>{t('bookingTestsRequired')}</p>}<div className="booking-total"><strong>{t('total')}</strong><strong>{money(totalPrice(ids, state.tests))}</strong></div><dl className="booking-summary-date"><dt>{t('selectedDate')}</dt><dd>{draft.date ? date(draft.date) : '—'}</dd><dt>{t('bookingTime')}</dt><dd><bdi>{draft.time || '—'}</bdi></dd></dl>{removable && <ui.Button secondary onClick={() => api.navigate('tests')}><Plus size={15} />{t('addMore')}</ui.Button>}</section>
}

function BookingDialog({ api, title, confirmLabel, cancelLabel = 'cancel', onConfirm, onClose, busy, children, amount }) {
  const dialog = useRef(null), titleId = useId()
  useEffect(() => { const node = dialog.current; node.showModal(); return () => { if (node.open) node.close() } }, [])
  return <dialog ref={dialog} className="portal-dialog booking-dialog" aria-labelledby={titleId} onCancel={event => { if (busy) event.preventDefault(); else onClose() }}><h2 id={titleId}>{api.t(title)}{amount !== undefined && <> {api.money(amount)}</>}</h2>{children}<div className="portal-actions"><button type="button" className="portal-button is-secondary" autoFocus disabled={busy} onClick={onClose}>{api.t(cancelLabel)}</button><button type="button" className="portal-button" disabled={busy} onClick={onConfirm}>{api.t(busy ? 'bookingProcessing' : confirmLabel)}</button></div></dialog>
}

export function BookingCheckout({ api, ui, query }) {
  const { state, dispatch, t, navigate } = api
  const draft = checkoutDraft(state), relatedId = new URLSearchParams(query).get('order')
  const [error, setError] = useState(''), [dialogOpen, setDialogOpen] = useState(false)
  // A pending existing order can enter booking without duplicating its tests/order.
  useEffect(() => {
    if (relatedId && state.orders.some(order => order.id === relatedId && order.status !== 'cancelled') && draft.orderId !== relatedId) dispatch({ type: 'CHECKOUT_EDIT', patch: { orderId: relatedId } })
  }, [relatedId, state.orders, draft.orderId, dispatch])
  function update(patch) { dispatch({ type: 'CHECKOUT_EDIT', patch }); setError('') }
  function review(event) { event.preventDefault(); const error = bookingDraftError(state); setError(error || ''); if (!error) setDialogOpen(true) }
  function confirm() {
    const error = bookingDraftError(state)
    if (error) { setError(error); setDialogOpen(false); return }
    dispatch({ type: 'CHECKOUT_REVIEW', requestId: crypto.randomUUID() }); setDialogOpen(false); navigate('payment')
  }
  // A completed checkout must not be silently replayed by browser Back.
  if (draft.stage === 'complete') return <><ui.Title title="bookTitle" /><ui.Empty title="bookingConfirmation" action="viewBooking" onClick={() => navigate(`booking-confirmation/${draft.bookingId}`)} /><ui.Button secondary onClick={() => { dispatch({ type: 'CHECKOUT_NEW' }); navigate('tests') }}>{t('browse')}</ui.Button></>
  return <><ui.Title title="bookTitle" hint="bookHint"><ui.Button secondary onClick={() => navigate('appointments')}>{t('appointments')}</ui.Button></ui.Title><section className="portal-card"><p className="portal-info"><strong>{t('availability')}</strong> · {t('availabilityHint')}</p><form noValidate onSubmit={review}><div className="portal-book-grid"><div><ui.CalendarPicker value={draft.date} onChange={date => update({ date, time: '' })} /><div className="portal-field-grid"><ui.Field label="type" name="appointment-type" value={draft.type} onChange={e => update({ type: e.target.value })}><option value="collection">{t('collection')}</option><option value="consultation">{t('consultation')}</option></ui.Field></div></div><fieldset className="portal-slots"><legend>{t('selectTime')}</legend><div>{timeSlots.map(time => <button key={time} type="button" aria-pressed={draft.time === time} disabled={!validSlot(draft.date, time, state.appointments) || draft.date > dateAtOffset(180)} onClick={() => update({ time })}><bdi>{time}</bdi></button>)}</div></fieldset></div><BookingSummary api={api} ui={ui} draft={{ ...draft, tests: selectedBookingTests(state, draft) }} removable />{error && <p className="portal-error" role="alert">{t(error)}</p>}<div className="portal-actions"><ui.Button secondary onClick={() => navigate('tests')}>{t('catalogBack')}</ui.Button><ui.Button type="submit">{t('bookingContinue')}</ui.Button></div></form></section>{dialogOpen && <BookingDialog api={api} title="bookingReviewTitle" confirmLabel="bookingConfirm" cancelLabel="bookingEdit" onClose={() => setDialogOpen(false)} onConfirm={confirm}><BookingSummary api={api} ui={ui} draft={{ ...draft, tests: selectedBookingTests(state, draft) }} /></BookingDialog>}</>
}

export function PaymentMethod({ api, ui }) {
  const { state, t, dispatch, navigate, busy, finishBooking } = api
  const draft = checkoutDraft(state)
  const [dialogOpen, setDialogOpen] = useState(false), [error, setError] = useState('')
  const submitLock = useRef(false)
  const hostedFields = useRef(null), reviewLock = useRef(false)
  const [receiptEmail, setReceiptEmail] = useState(state.profile.email || '')
  const [emailError, setEmailError] = useState(false), [checkingCard, setCheckingCard] = useState(false)
  if (draft.stage === 'complete') return <BookingReceipt api={api} ui={ui} id={draft.bookingId} />
  if (draft.stage === 'pending') return <BookingReceipt api={api} ui={ui} id="pending" />
  if (!['reviewed', 'processing'].includes(draft.stage) || !draft.tests?.length) return <><ui.Title title="payment" /><ui.Empty title="bookingNoDraft" action="book" onClick={() => navigate('book')} /></>
  async function openDialog() {
    if (reviewLock.current || busy) return
    if (!draft.method) { setError('paymentChoose'); return }
    const invalid = bookingDraftError(state)
    if (invalid) { setError(invalid); return }
    setError('')
    if (draft.method === 'online') {
      if (!validReceiptEmail(receiptEmail)) { setEmailError(true); return }
      reviewLock.current = true; setCheckingCard(true)
      try {
        const problem = await hostedFields.current?.validate() || (!hostedFields.current ? 'cardUnavailable' : null)
        if (problem) { setError(problem); return }
      } catch { setError('cardUnavailable'); return }
      finally { reviewLock.current = false; setCheckingCard(false) }
    }
    setDialogOpen(true)
  }
  async function submit() {
    if (submitLock.current) return
    if (draft.method === 'online' && !validReceiptEmail(receiptEmail)) { setEmailError(true); setDialogOpen(false); return }
    submitLock.current = true
    try {
      const result = await finishBooking(draft.method === 'online' ? { receiptEmail: receiptEmail.trim(), confirmCard: session => hostedFields.current.confirm(session) } : undefined)
      setDialogOpen(false)
      if (result.ok) navigate(`booking-confirmation/${result.bookingId}`)
      else if (result.pending) navigate('booking-confirmation/pending')
      else setError(result.error)
    } catch { setDialogOpen(false); setError('bookingUnavailable') }
    finally { submitLock.current = false }
  }
  return <><ui.Title title="payment" hint="paymentHint" /><div className="portal-two-col"><section className="portal-card"><fieldset className="booking-payment-options" disabled={busy || checkingCard}><legend>{t('payment')}</legend>{[['online', CreditCard, 'onlineHint'], ['laboratory', Building2, 'laboratoryHint']].map(([method, Icon, hint]) => <label className={draft.method === method ? 'is-selected' : ''} key={method}><input type="radio" name="payment-method" value={method} checked={draft.method === method} onChange={() => { dispatch({ type: 'CHECKOUT_METHOD', method }); setError('') }} /><Icon size={24} aria-hidden="true" /><span><strong>{t(method)}</strong><small>{t(hint)}</small></span></label>)}</fieldset>{draft.method === 'online' && <HostedCardForm key={api.language} ref={hostedFields} t={t} disabled={busy || checkingCard} language={api.language} receiptEmail={receiptEmail} emailError={emailError} onEmailChange={value => { setReceiptEmail(value); setEmailError(false); setError('') }} />}{error && <p className="portal-error" role="alert">{t(error)}</p>}<div className="portal-actions"><ui.Button secondary disabled={busy || checkingCard} onClick={() => navigate('book')}>{t('bookingEdit')}</ui.Button><ui.Button disabled={busy || checkingCard} onClick={openDialog}>{busy || checkingCard ? t('bookingProcessing') : draft.method === 'online' ? <>{t('cardPayLabel')} {api.money(totalPrice(draft.tests, state.tests))}</> : t(draft.method === 'laboratory' ? 'confirmBooking' : 'confirmPay')}</ui.Button></div></section><section className="portal-card"><BookingSummary api={api} ui={ui} draft={draft} /></section></div>{dialogOpen && <BookingDialog api={api} title="bookingFinalReview" confirmLabel="confirmBooking" cancelLabel="bookingEdit" busy={busy} onClose={() => setDialogOpen(false)} onConfirm={submit}><BookingSummary api={api} ui={ui} draft={draft} finalReview /></BookingDialog>}</>
}

export function BookingReceipt({ api, ui, id, details = false }) {
  const { state, t, navigate, money, date, local, dispatch, name } = api
  const draft = checkoutDraft(state)
  const pending = id === 'pending' && draft.stage === 'pending'
  const saved = state.appointments.find(appointment => appointment.id === id && appointment.tests?.length && appointment.serverConfirmed === true && appointment.source === 'server' && (details || appointment.status === 'confirmed'))
  const appointment = pending ? { ...draft, id: null, patientName: name || state.profile.name, tests: draft.tests || [], total: totalPrice(draft.tests || [], state.tests), paymentMethod: draft.method, paymentStatus: 'pending' } : saved
  if (!appointment) return <><ui.Title title="bookingDetails" /><ui.Empty title="notFound" action="appointments" onClick={() => navigate('appointments')} /></>
  const paidOnline = !pending && appointment.paymentMethod === 'online' && appointment.paymentStatus === 'paid'
  const tests = appointment.tests.map(id => local(state.tests.find(test => test.id === id)?.name || id)).join(', ')
  return <><ui.Title title={details ? 'bookingDetails' : 'bookingConfirmation'} /><article className="portal-card booking-receipt">{!details && <div className="booking-success">{pending ? <Clock size={42} aria-hidden="true" /> : <CheckCircle2 size={42} aria-hidden="true" />}<h2>{t(pending ? 'bookingAwaiting' : 'bookingSuccess')}</h2><p>{t(pending ? 'bookingAwaitingHint' : 'bookingSuccessHint')}</p><p>{t(pending ? 'selectedBookingSchedule' : 'bookingSchedule', { date: date(appointment.date), time: appointment.time, tests })}</p></div>}<dl className="booking-receipt-details">{[['bookingReference', <bdi key="reference">{appointment.id || String.fromCharCode(8212)}</bdi>], ['name', appointment.patientName || String.fromCharCode(8212)], ['selectedDate', date(appointment.date)], ['bookingTime', <bdi key="time">{appointment.time}</bdi>], ['count', appointment.tests.length], ['total', money(appointment.total)], ['payment', t(appointment.paymentMethod)], ['status', t(pending ? 'pending' : appointment.status)], ['paymentStatus', t(pending ? 'awaitingPayment' : appointment.paymentStatus === 'paid' ? 'paid' : 'awaitingPayment')]].map(([key, value]) => <div key={key}><dt>{t(key)}</dt><dd>{value}</dd></div>)}</dl>{pending && draft.failure && <p className="portal-error" role="alert">{t(draft.failure)}</p>}<h2>{t('bookingSelected')}</h2><ul className="booking-receipt-tests">{appointment.tests.map(id => <li key={id}>{local(state.tests.find(test => test.id === id)?.name || id)}</li>)}</ul><p className="portal-info">{t(pending ? appointment.paymentMethod === 'online' ? 'paymentAwaiting' : 'bookingAwaitingHint' : paidOnline ? 'onlinePaid' : 'laboratoryPending')}</p><div className="portal-actions">{pending && <><ui.Button onClick={() => { dispatch({ type: 'CHECKOUT_RETRY' }); navigate('payment') }}>{t('retry')}</ui.Button><ui.Button secondary onClick={() => navigate('book')}>{t('bookingEdit')}</ui.Button></>}<ui.Button onClick={() => navigate('appointments')}>{t('viewAppointments')}</ui.Button>{!details && !pending && <ui.Button secondary onClick={() => navigate(`appointments/${appointment.id}`)}>{t('viewBooking')}</ui.Button>}{appointment.orderId && <ui.Button secondary onClick={() => navigate(`orders/${appointment.orderId}`)}>{t('orders')}</ui.Button>}<ui.Button secondary onClick={() => navigate('dashboard')}>{t('bookingHome')}</ui.Button></div></article></>
}
