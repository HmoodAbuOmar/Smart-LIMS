import { createContext, useContext, useEffect, useId, useReducer, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ArrowLeft, ArrowRight, Bell, CalendarDays, Check, CheckCircle2, ChevronDown, ClipboardList, Clock, Download, FileText, FlaskConical, Heart, History, LayoutDashboard, LogOut, Menu, Plus, Printer, Search, ShieldCheck, Trash2, UserRound, X } from 'lucide-react'
import LanguageSwitcher from '../components/LanguageSwitcher.jsx'
import BrandLogo from '../components/BrandLogo.jsx'
import MedicalHistory, { HealthTrendsPreview } from './MedicalHistory.jsx'
import { visitForAppointment, visitForOrder, visitForResult } from './historyModel.js'
import { dateAtOffset, portalReducer, timeSlots, todayValue, totalPrice, validSlot, validateProfile } from './portalModel.js'
import { formatCurrency } from '../utils/currency.js'
import { BookingCheckout, BookingReceipt, PaymentMethod } from './BookingFlow.jsx'
import { bookingDraftError, checkoutDraft } from './bookingModel.js'
import { bookingApi, portalApi } from '../services/portalApi.js'
import { processHostedPayment } from '../services/hostedPayment.js'
import { isInternalRecord, patientFacingWorkspace, verifiedBookingResponse } from './patientState.js'
import './Portal.css'

const Portal = createContext(null)
const usePortal = () => useContext(Portal)
const navItems = [['dashboard', LayoutDashboard], ['tests', FlaskConical], ['orders', ClipboardList], ['appointments', CalendarDays], ['results', FileText], ['history', History], ['notifications', Bell], ['profile', UserRound]]
const categories = ['blood', 'vitamins', 'thyroid', 'liver', 'kidney', 'lipids', 'diabetes']

export default function PatientPortal({ initialData, development = false, route = 'dashboard', onNavigate, onExit, onBack, onStateChange }) {
  const { i18n } = useTranslation()
  const { t } = useTranslation('portal')
  const [state, dispatch] = useReducer(portalReducer, initialData, data => import.meta.env.DEV && development ? data : patientFacingWorkspace(data))
  useEffect(() => { if (import.meta.env.DEV && development) onStateChange?.(state) }, [state, development, onStateChange])
  const [notice, setNotice] = useState('')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [accountOpen, setAccountOpen] = useState(false)
  const [globalSearch, setGlobalSearch] = useState('')
  const [busy, setBusy] = useState(false)
  const [transactionBusy, setTransactionBusy] = useState(false)
  const bookingLock = useRef(false)
  const accountRef = useRef(null)
  const language = i18n.resolvedLanguage === 'ar' ? 'ar' : 'en'
  const local = value => Array.isArray(value) ? value[language === 'ar' ? 1 : 0] : value
  const date = value => value ? new Intl.DateTimeFormat(language, { dateStyle: 'medium' }).format(new Date(value.length === 10 ? `${value}T12:00:00` : value)) : '—'
  const money = value => <bdi dir="ltr">{formatCurrency(value, language)}</bdi>
  const number = value => new Intl.NumberFormat(language).format(value)
  const datetime = value => new Intl.DateTimeFormat(language, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
  const name = language === 'ar' && state.profile.nameAr ? state.profile.nameAr : state.profile.name || t('samplePatient')
  const navigate = path => { if (bookingLock.current) return; setMobileOpen(false); setAccountOpen(false); setNotice(''); onNavigate(path) }
  const [path, query = ''] = route.split('?'), [page = 'dashboard', id] = path.split('/')
  useEffect(() => { document.title = 'Smart-LIMS'; document.querySelector('.portal-page-title')?.focus(); window.scrollTo({ top: 0, behavior: 'instant' }) }, [route, t, page])
  useEffect(() => {
    function close(event) { if (accountRef.current && !accountRef.current.contains(event.target)) setAccountOpen(false) }
    function escape(event) { if (event.key === 'Escape') { setMobileOpen(false); setAccountOpen(false) } }
    document.addEventListener('pointerdown', close); document.addEventListener('keydown', escape)
    return () => { document.removeEventListener('pointerdown', close); document.removeEventListener('keydown', escape) }
  }, [])
  async function commit(action, message) {
    if (import.meta.env.DEV && development) {
      // Original local reducer actions are scoped to the fixture workspace.
      // They never invoke an API or alter authentication/authorization state.
      if (action.type === 'ORDER') {
        const id = `SAMPLE-${crypto.randomUUID()}`
        dispatch({ ...action, id, date: todayValue() })
        if (message) setNotice(message)
        return { order: { id } }
      }
      dispatch(action)
      if (message) setNotice(message)
      return true
    }
    setBusy(true)
    try {
      const operations = { PROFILE: 'saveProfile', ORDER: 'createOrder', APPOINTMENT: action.existing ? 'rescheduleAppointment' : 'bookAppointment', CANCEL: 'cancelAppointment' }
      const operation = operations[action.type]
      if (!operation) throw new Error('Unsupported operation')
      const response = await portalApi[operation](action)
      if (response?.confirmed !== true) throw new Error('Operation was not confirmed')
      if (action.type === 'PROFILE') {
        if (!response.profile || response.profile.fileNumber !== state.profile.fileNumber) throw new Error('Profile was not confirmed')
        dispatch({ type: 'PROFILE', profile: response.profile })
      } else {
        const collection = action.type === 'ORDER' ? 'orders' : 'appointments'
        const record = action.type === 'ORDER' ? response.order : response.appointment
        if (!record?.id || isInternalRecord(record) || record.patientId !== state.profile.fileNumber) throw new Error('Record was not confirmed')
        dispatch({ type: 'SERVER_RECORD', collection, record: { ...record, source: 'server' } })
      }
      if (message) setNotice(message)
      return response
    } catch { setNotice('operationPending'); return false }
    finally { setBusy(false) }
  }
  async function finishBooking(options = {}) {
    const draft = checkoutDraft(state)
    if (bookingLock.current || draft.stage !== 'reviewed') return { ok: false, error: 'bookingUnavailable' }
    const invalid = bookingDraftError(state)
    if (invalid) return { ok: false, error: invalid }
    bookingLock.current = true; setTransactionBusy(true); dispatch({ type: 'CHECKOUT_START' })
    try {
      const payload = { requestId: draft.requestId, tests: draft.tests, date: draft.date, time: draft.time, method: draft.method, type: draft.type, orderId: draft.orderId || undefined }
      let response
      if (draft.method === 'online') {
        response = await processHostedPayment({ api: bookingApi, payload, receiptEmail: options.receiptEmail, confirmCard: options.confirmCard, expectedAmount: totalPrice(draft.tests, state.tests) })
      } else response = await bookingApi.confirmPayAtLaboratory(payload)
      const verified = verifiedBookingResponse(response, draft, state.profile)
      if (!verified) { dispatch({ type: 'CHECKOUT_PENDING', requestId: draft.requestId, failure: 'bookingUnavailable' }); return { ok: false, pending: true } }
      dispatch({ type: 'CHECKOUT_SERVER_COMPLETE', requestId: draft.requestId, ...verified })
      return { ok: true, bookingId: verified.appointment.id }
    } catch (error) {
      if (error.code === 'BOOKING_CONFLICT') { dispatch({ type: 'CHECKOUT_FAILED', requestId: draft.requestId }); return { ok: false, error: 'bookingConflict' } }
      if (error.code === 'PAYMENT_DECLINED') { dispatch({ type: 'CHECKOUT_FAILED', requestId: draft.requestId }); return { ok: false, error: 'paymentUnavailable' } }
      dispatch({ type: 'CHECKOUT_PENDING', requestId: draft.requestId, failure: draft.method === 'online' ? 'paymentUnavailable' : 'bookingUnavailable' })
      return { ok: false, pending: true }
    } finally { bookingLock.current = false; setTransactionBusy(false) }
  }
  function addAndBook(id) { if (!bookingLock.current) { dispatch({ type: 'ADD', id }); navigate('book') } }
  const value = { state, dispatch, development, t, local, date, money, number, name, navigate, commit, notice, setNotice, busy: busy || transactionBusy, language, datetime, finishBooking, addAndBook }
  const bookingUi = { Title, Button, Empty, Field, CalendarPicker }
  const historyUi = { Title, Button, Empty, Field, Status, FilterTabs, ReportDownload }
  const unread = state.notifications.filter(n => !n.read).length
  const rootPage = ['book', 'payment', 'booking-confirmation'].includes(page) ? 'appointments' : page === 'review' ? 'orders' : page
  function submitSearch(event) { event.preventDefault(); navigate(`tests?q=${encodeURIComponent(globalSearch.trim())}`) }
  return <Portal.Provider value={value}><div className="patient-portal" dir={language === 'ar' ? 'rtl' : 'ltr'}>
    <a href="#portal-content" className="portal-skip" onClick={e => { e.preventDefault(); document.querySelector('.portal-page-title')?.focus() }}>{t('skip')}</a>
    {mobileOpen && <button type="button" className="portal-scrim" aria-label={t('close')} onClick={() => setMobileOpen(false)} />}
    <aside className={`portal-sidebar ${mobileOpen ? 'is-open' : ''}`} aria-label={t('menu')}>
      <button className="portal-logo" onClick={() => navigate('dashboard')} aria-label="Smart-LIMS"><BrandLogo /></button>
      <button type="button" className="portal-mobile-close" onClick={() => setMobileOpen(false)} aria-label={t('close')}><X size={20} /></button>
      <nav>{navItems.map(([key, Icon]) => <button key={key} data-page={key} aria-current={rootPage === key ? 'page' : undefined} onClick={() => navigate(key)}><Icon size={18} /><span>{t(key)}</span>{key === 'notifications' && unread > 0 && <small>{number(unread)}</small>}</button>)}</nav>
      <div className="portal-sidebar-bottom"><LanguageSwitcher /></div>
    </aside>
    <div className="portal-workspace">
      <header className="portal-topbar">
        <button type="button" className="portal-menu" aria-label={t('menu')} aria-expanded={mobileOpen} onClick={() => setMobileOpen(!mobileOpen)}><Menu /></button>
        <form role="search" className="portal-search" onSubmit={submitSearch}><Search size={16} aria-hidden="true" /><input name="portal-search" aria-label={t('search')} placeholder={t('search')} value={globalSearch} onChange={e => setGlobalSearch(e.target.value)} /><button type="submit" aria-label={t('search')}><ArrowRight size={17} /></button></form>
        <button className="portal-bell" onClick={() => navigate('notifications')} aria-label={`${t('notifications')}: ${number(unread)}`}><Bell size={20} />{unread > 0 && <span>{number(unread)}</span>}</button>
        <div className="portal-account" ref={accountRef}><button type="button" aria-label={t('account')} aria-expanded={accountOpen} onClick={() => setAccountOpen(!accountOpen)}><span className="portal-avatar"><UserRound size={18} /></span><span className="portal-account-name">{name}</span><ChevronDown size={14} /></button>
          {accountOpen && <div className="portal-account-menu"><button onClick={() => navigate('profile')}><UserRound size={16} />{t('profile')}</button><button onClick={onExit}><LogOut size={16} />{t('logout')}</button></div>}
        </div>
      </header>
      <main id="portal-content" className="portal-main">
        <nav className="portal-breadcrumb" aria-label={t('home')}>{onBack && page === 'dashboard' && <><button className="portal-onboarding-back" onClick={onBack}>{t('back')}</button><span>·</span></>}<button onClick={() => navigate('dashboard')}>{t('home')}</button><span>/</span><span>{t(rootPage === 'tests' && id ? 'test' : rootPage === 'results' && id ? 'resultReport' : page === 'review' ? 'reviewTitle' : page === 'book' ? 'bookTitle' : page === 'payment' ? 'payment' : page === 'booking-confirmation' ? 'bookingConfirmation' : rootPage)}</span></nav>
        {notice && <div className={`portal-notice ${notice === 'unavailable' || notice === 'pdfError' ? 'is-error' : ''}`} role="status">{t(notice)}<button aria-label={t('close')} onClick={() => setNotice('')}><X size={16} /></button></div>}
        {page === 'dashboard' ? <Dashboard /> : page === 'profile' ? <Profile /> : page === 'tests' && id ? <TestDetails id={id} /> : page === 'tests' ? <Catalog key={query} query={query} /> : page === 'review' ? <Review /> : page === 'orders' && id ? <OrderDetails id={id} /> : page === 'orders' ? <Orders /> : page === 'book' ? (new URLSearchParams(query).has('reschedule') ? <Booking key={query} query={query} /> : <BookingCheckout api={value} ui={bookingUi} query={query} />) : page === 'payment' ? <PaymentMethod api={value} ui={bookingUi} /> : page === 'booking-confirmation' ? <BookingReceipt api={value} ui={bookingUi} id={id} /> : page === 'appointments' && id ? <BookingReceipt api={value} ui={bookingUi} id={id} details /> : page === 'appointments' ? <Appointments /> : page === 'results' && id ? <Report id={id} /> : page === 'results' ? <Results /> : page === 'history' ? <MedicalHistory key={id || 'archive'} api={value} ui={historyUi} visitId={id} query={query} /> : page === 'notifications' ? <Notifications /> : <Empty title="notFound" action="backDashboard" onClick={() => navigate('dashboard')} />}
      </main>
    </div>
  </div></Portal.Provider>
}

function Title({ title, hint, children }) { const { t } = usePortal(); return <div className="portal-heading"><div><h1 className="portal-page-title" tabIndex={-1}>{t(title)}</h1>{hint && <p>{t(hint)}</p>}</div>{children}</div> }
function Button({ children, onClick, secondary = false, ...props }) { return <button type="button" className={`portal-button ${secondary ? 'is-secondary' : ''}`} onClick={onClick} {...props}>{children}</button> }
function VisitLink({ visit }) { const { t, navigate } = usePortal(); return visit ? <Button secondary onClick={() => navigate(`history/${visit.id}`)}>{t('viewVisit')}</Button> : null }
function Status({ value }) { const { t } = usePortal(); return <span className={`portal-status status-${value}`}>{t(value === 'published' ? 'available' : value)}</span> }
function Empty({ title = 'noMatches', action = 'clear', onClick }) { const { t } = usePortal(); return <div className="portal-empty"><FlaskConical size={30} /><h2>{t(title)}</h2>{title === 'noMatches' && <p>{t('noMatchesHint')}</p>}{onClick && <Button secondary onClick={onClick}>{t(action)}</Button>}</div> }
function Card({ title, action, children }) { const { t } = usePortal(); return <section className="portal-card"><div className="portal-card-heading"><h2>{t(title)}</h2>{action}</div>{children}</section> }
function FilterTabs({ options, value, onChange }) { const { t } = usePortal(); return <div className="portal-filter-tabs" role="group" aria-label={t('status')}>{options.map(option => <button key={option} aria-pressed={value === option} onClick={() => onChange(option)}>{t(option)}</button>)}</div> }
function OrderTable({ orders }) { const { t, state, date, money, number, navigate } = usePortal(); return <div className="portal-table-wrap" tabIndex={0}><table><caption className="portal-sr-only">{t('orders')}</caption><thead><tr>{['orderNumber', 'date', 'count', 'amount', 'status', 'actions'].map(k => <th key={k} scope="col">{t(k)}</th>)}</tr></thead><tbody>{orders.map(order => <tr key={order.id}><th scope="row"><bdi>{order.id}</bdi></th><td>{date(order.date)}</td><td>{number(order.tests.length)}</td><td>{money(order.total)}</td><td><Status value={order.status} /></td><td><Button secondary onClick={() => navigate(`orders/${order.id}`)}>{t('view')}</Button> <VisitLink visit={visitForOrder(state, order.id)} /></td></tr>)}</tbody></table></div> }
function ResultList({ results }) { const { state, local, navigate, date } = usePortal(); return <div className="portal-result-list">{results.map(r => <button key={r.id} onClick={() => navigate(`results/${r.id}`)}><span className="portal-icon"><FileText size={20} /></span><span><strong>{local(state.tests.find(test => test.id === r.testId).name)}</strong><small>{date(r.date)}</small></span><ArrowRight size={16} /></button>)}</div> }
function Dashboard() {
  const api = usePortal()
  const { t, state, name, number, navigate, local, date } = usePortal()
  const upcoming = state.appointments.filter(a => a.status === 'confirmed' && new Date(`${a.date}T${a.time}`) > new Date()).sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
  const published = state.results.filter(r => r.status === 'published')
  const summaries = [['totalOrders', state.orders.length, ClipboardList, 'orders'], ['upcomingAppointments', upcoming.length, CalendarDays, 'appointments'], ['availableResults', published.length, FileText, 'results'], ['unread', state.notifications.filter(n => !n.read).length, Bell, 'notifications']]
  return <>
    <section className="portal-welcome"><div><p>{t('welcome')}</p><h1 className="portal-page-title" tabIndex={-1}>{name}</h1><p>{t('welcomeHint')}</p></div></section>
    <div className="portal-stats">{summaries.map(([label, count, Icon, target]) => <button key={label} className="portal-stat" onClick={() => navigate(target)}><span className="portal-icon"><Icon size={23} /></span><strong>{number(count)}</strong><span>{t(label)}</span><small>{t('viewAll')} <ArrowRight size={12} /></small></button>)}</div>
    <div className="portal-quick"><h2>{t('quick')}</h2><div>{[['browse', 'tests', FlaskConical], ['book', 'book', CalendarDays], ['orders', 'orders', ClipboardList], ['results', 'results', FileText]].map(([key, route, Icon]) => <Button key={key} secondary onClick={() => navigate(route)}><Icon size={16} />{t(key)}</Button>)}</div></div>
    <HealthTrendsPreview api={api} />
    <div className="portal-two-col"><Card title="recentOrders" action={<button className="portal-text" onClick={() => navigate('orders')}>{t('viewAll')}</button>}><OrderTable orders={[...state.orders].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 3)} /></Card><Card title="nextAppointment">{upcoming[0] ? <div className="portal-next"><CalendarDays size={30} /><h3>{date(upcoming[0].date)}</h3><strong><bdi>{upcoming[0].time}</bdi></strong><p>{t(upcoming[0].type)}</p><Status value={upcoming[0].status} /><Button onClick={() => navigate('appointments')}>{t('appointments')}</Button></div> : <Empty title="noAppointments" action="book" onClick={() => navigate('book')} />}</Card></div>
    <div className="portal-two-col"><Card title="latestResults" action={<button className="portal-text" onClick={() => navigate('results')}>{t('viewAll')}</button>}>{published.length ? <ResultList results={published.slice(0, 3)} /> : <Empty title="noResults" />}</Card><Card title="popular" action={<button className="portal-text" onClick={() => navigate('tests')}>{t('viewAll')}</button>}><div className="portal-popular">{state.tests.slice(0, 4).map(test => <button key={test.id} onClick={() => navigate(`tests/${test.id}`)}><span className="portal-icon"><FlaskConical size={19} /></span><span>{local(test.name)}</span></button>)}</div></Card></div>
  </>
}

function Field({ label, name, error, children, ...props }) { const { t } = usePortal(); const id = useId(); return <div className="portal-field"><label htmlFor={id}>{t(label)}</label>{children ? <select id={id} name={name} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} {...props}>{children}</select> : <input id={id} name={name} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} {...props} />}{error && <span id={`${id}-error`} className="portal-error">{t(error)}</span>}</div> }
function Profile() {
  const { state, t, commit, navigate, busy } = usePortal()
  const [draft, setDraft] = useState(state.profile), [errors, setErrors] = useState({}), [editing, setEditing] = useState(false)
  const completion = Math.round(['name', 'dateOfBirth', 'gender', 'phone', 'email'].filter(k => draft[k] && !validateProfile(draft)[k]).length / 5 * 100)
  function update(e) { setDraft(d => ({ ...d, [e.target.name]: e.target.value })); setErrors(p => ({ ...p, [e.target.name]: undefined })) }
  async function save(e) { e.preventDefault(); const nextErrors = validateProfile(draft); setErrors(nextErrors); if (Object.keys(nextErrors).length) { e.currentTarget.querySelector(`[name='${Object.keys(nextErrors)[0]}']`)?.focus(); return } if (await commit({ type: 'PROFILE', profile: { ...draft, name: draft.name.trim(), nameAr: draft.name !== state.profile.name ? '' : draft.nameAr } }, 'saved')) setEditing(false) }
  return <><Title title="completeProfile" hint="profileHint"><Button secondary onClick={() => { if (editing) { setDraft(state.profile); setErrors({}) } setEditing(!editing) }}>{t(editing ? 'cancel' : 'edit')}</Button></Title><div className="portal-profile-progress"><span>{t('progress')} · {completion}%</span><progress max="100" value={completion} aria-label={t('progress')} /></div><div className="portal-two-col"><section className="portal-card"><form onSubmit={save} noValidate className="portal-form"><h2>{t('personal')}</h2><fieldset disabled={!editing || busy}><div className="portal-field-grid"><Field label="name" name="name" value={draft.name} onChange={update} error={errors.name} required autoComplete="name" maxLength={100} /><Field label="dob" name="dateOfBirth" type="date" max={todayValue()} min="1900-01-01" value={draft.dateOfBirth} onChange={update} error={errors.dateOfBirth} required /><Field label="gender" name="gender" value={draft.gender} onChange={update} error={errors.gender} required><option value="">{t('choose')}</option><option value="male">{t('male')}</option><option value="female">{t('female')}</option></Field></div><h2>{t('contact')}</h2><div className="portal-field-grid"><Field label="phone" name="phone" type="tel" dir="ltr" value={draft.phone} onChange={update} error={errors.phone} required autoComplete="tel" /><Field label="email" name="email" type="email" dir="ltr" value={draft.email} onChange={update} error={errors.email} required autoComplete="email" /><Field label="address" name="address" value={draft.address} onChange={update} error={errors.address} autoComplete="street-address" maxLength={200} /></div></fieldset>{Object.values(errors).some(Boolean) && <p className="portal-error" role="alert">{t('validation')}</p>}{editing && <Button type="submit" disabled={busy}>{t(busy ? 'saving' : 'save')}</Button>}<Button secondary onClick={() => navigate('dashboard')}>{t('backDashboard')}</Button><Button secondary onClick={() => navigate('history')}>{t('history')}</Button></form></section><Card title="why"><ShieldCheck className="portal-feature-icon" size={40} /><p>{t('whyHint')}</p></Card></div></>
}

function Catalog({ query }) {
  const { state, t, local, money, navigate, addAndBook } = usePortal()
  const [search, setSearch] = useState(new URLSearchParams(query).get('q') || ''), [category, setCategory] = useState('all')
  const matches = state.tests.filter(test => (category === 'all' || category === test.category) && `${local(test.name)} ${local(test.description)}`.toLocaleLowerCase().includes(search.toLocaleLowerCase().trim()))
  const reset = () => { setSearch(''); setCategory('all') }
  return <><Title title="tests" hint="catalogHint"><Button onClick={() => navigate('review')}>{t('review')} ({state.cart.length})</Button></Title><div className="portal-controls"><div className="portal-field portal-catalog-search"><Search size={17} aria-hidden="true" /><input name="test-search" type="search" aria-label={t('search')} placeholder={t('search')} value={search} onChange={e => setSearch(e.target.value)} /></div><Field label="category" name="test-category" value={category} onChange={e => setCategory(e.target.value)}><option value="all">{t('allCategories')}</option>{categories.map(k => <option key={k} value={k}>{t(k)}</option>)}</Field><button className="portal-text" onClick={reset}>{t('clear')}</button></div><FilterTabs options={['all', ...categories]} value={category} onChange={setCategory} />{matches.length ? <div className="portal-test-grid">{matches.map(test => <article className="portal-test-card" key={test.id}><span className="portal-icon"><FlaskConical size={23} /></span><small>{t(test.category)}</small><h2>{local(test.name)}</h2><p>{local(test.description)}</p><strong>{money(test.price)}</strong><div><Button secondary onClick={() => navigate(`tests/${test.id}`)}>{t('view')}</Button><Button disabled={state.cart.includes(test.id)} onClick={() => addAndBook(test.id)}>{state.cart.includes(test.id) ? <Check size={15} /> : <Plus size={15} />}{t(state.cart.includes(test.id) ? 'added' : 'add')}</Button></div></article>)}</div> : <Empty onClick={reset} />}</>
}
function TestDetails({ id }) {
  const { state, t, local, money, navigate, addAndBook } = usePortal(), test = state.tests.find(item => item.id === id)
  if (!test) return <Empty title="notFound" action="catalogBack" onClick={() => navigate('tests')} />
  return <><Title title="test"><Button secondary onClick={() => navigate('tests')}><ArrowLeft size={16} />{t('catalogBack')}</Button></Title><article className="portal-card portal-test-detail"><div className="portal-test-detail-head"><span className="portal-icon"><FlaskConical size={34} /></span><div><h2>{local(test.name)}</h2><p>{t(test.category)}</p></div><div><strong>{money(test.price)}</strong><Button disabled={state.cart.includes(id)} onClick={() => addAndBook(id)}>{t(state.cart.includes(id) ? 'added' : 'add')}</Button></div></div><p>{local(test.description)}</p><div className="portal-detail-grid">{[['sampleType', local(test.sample), FlaskConical], ['preparation', local(test.prep), ClipboardList], ['turnaround', local(test.time), Clock], ['fasting', t(test.fasting ? 'required' : 'notRequired'), Heart]].map(([label, text, Icon]) => <div key={label}><Icon size={22} /><h3>{t(label)}</h3><p>{text}</p></div>)}</div><h3>{t('referenceInfo')}</h3><p>{t('referenceHint')}</p><Button onClick={() => navigate('review')}>{t('review')} ({state.cart.length})</Button></article></>
}
function Review() {
  const { state, t, local, money, navigate, dispatch, commit, busy, setNotice } = usePortal()
  async function confirm() { const response = await commit({ type: 'ORDER', requestId: crypto.randomUUID(), tests: state.cart }); if (response?.order) { navigate(`orders/${response.order.id}`); setNotice('orderSaved') } }
  return <><Title title="reviewTitle" hint="reviewHint" />{!state.cart.length ? <Empty title="emptyCart" action="browse" onClick={() => navigate('tests')} /> : <div className="portal-two-col"><section className="portal-card"><div className="portal-table-wrap"><table><thead><tr><th>{t('test')}</th><th>{t('price')}</th><th>{t('remove')}</th></tr></thead><tbody>{state.cart.map(id => { const test = state.tests.find(t => t.id === id); return <tr key={id}><th scope="row">{local(test.name)}</th><td>{money(test.price)}</td><td><button className="portal-danger-icon" aria-label={`${t('remove')} ${local(test.name)}`} onClick={() => dispatch({ type: 'REMOVE', id })}><Trash2 size={17} /></button></td></tr> })}</tbody><tfoot><tr><th>{t('total')}</th><td colSpan={2}>{money(totalPrice(state.cart, state.tests))}</td></tr></tfoot></table></div><div className="portal-actions"><Button secondary onClick={() => navigate('tests')}><Plus size={16} />{t('addMore')}</Button><Button disabled={busy} onClick={confirm}>{t(busy ? 'saving' : 'confirmOrder')}<ArrowRight size={16} /></Button></div></section><Card title="patientInfo"><dl className="portal-definition"><dt>{t('name')}</dt><dd>{state.profile.name}</dd><dt>{t('fileNumber')}</dt><dd><bdi>{state.profile.fileNumber}</bdi></dd><dt>{t('phone')}</dt><dd><bdi>{state.profile.phone}</bdi></dd></dl></Card></div>}</>
}
function Orders() {
  const { state } = usePortal(), [status, setStatus] = useState('all'), [search, setSearch] = useState('')
  const orders = state.orders.filter(order => (status === 'all' || status === order.status) && order.id.toLowerCase().includes(search.trim().toLowerCase()))
  return <><Title title="orders" hint="ordersHint" /><FilterTabs options={['all', 'pending', 'inProgress', 'completed', 'cancelled']} value={status} onChange={setStatus} /><div className="portal-controls"><Field label="searchOrders" name="order-search" type="search" value={search} onChange={e => setSearch(e.target.value)} /></div><section className="portal-card">{orders.length ? <OrderTable orders={orders} /> : <Empty onClick={() => { setSearch(''); setStatus('all') }} />}</section></>
}
function OrderDetails({ id }) {
  const { state, t, local, money, date, navigate } = usePortal(), order = state.orders.find(o => o.id === id)
  if (!order) return <Empty title="notFound" action="orders" onClick={() => navigate('orders')} />
  return <><Title title="order"><Button secondary onClick={() => navigate('orders')}><ArrowLeft size={16} />{t('orders')}</Button></Title><VisitLink visit={visitForOrder(state, id)} /><section className="portal-card"><div className="portal-card-heading"><div><h2><bdi>{order.id}</bdi></h2><p>{date(order.date)}</p></div><Status value={order.status} /></div><ol className="portal-timeline">{['placed', 'collected', 'inLab', 'completed'].map((key, index) => <li key={key} className={index <= order.stage && order.status !== 'cancelled' ? 'is-done' : ''} aria-current={index === order.stage ? 'step' : undefined}><span>{index <= order.stage && order.status !== 'cancelled' ? <Check size={16} /> : index + 1}</span><strong>{t(key)}</strong></li>)}</ol><div className="portal-metrics"><span>{t('sampleStatus')}: <strong>{t(order.stage >= 1 ? 'collected' : 'notYet')}</strong></span><span>{t('processing')}: <strong>{t(order.status)}</strong></span><span>{t('total')}: <strong>{money(order.total)}</strong></span></div><h3>{t('count')}</h3><div className="portal-table-wrap"><table><thead><tr><th>{t('test')}</th><th>{t('status')}</th><th>{t('actions')}</th></tr></thead><tbody>{order.tests.map(id => { const test = state.tests.find(t => t.id === id), result = state.results.find(r => r.orderId === order.id && r.testId === id && r.status === 'published'); return <tr key={id}><th scope="row">{local(test.name)}</th><td><Status value={result ? 'completed' : order.status} /></td><td><Button secondary disabled={!result} onClick={() => navigate(`results/${result.id}`)}>{t('viewResult')}</Button></td></tr> })}</tbody></table></div>{order.status === 'pending' && <Button onClick={() => navigate(`book?order=${encodeURIComponent(id)}`)}>{t('book')}</Button>}</section></>
}

function CalendarPicker({ value, onChange }) {
  const { t, language, number } = usePortal()
  const [month, setMonth] = useState(() => new Date(`${value}T12:00:00`))
  const first = new Date(month.getFullYear(), month.getMonth(), 1)
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate()
  const min = todayValue(), max = dateAtOffset(180)
  const label = new Intl.DateTimeFormat(language, { month: 'long', year: 'numeric' }).format(month)
  const weekdays = Array.from({ length: 7 }, (_, i) => new Intl.DateTimeFormat(language, { weekday: 'short' }).format(new Date(2026, 0, 4 + i)))
  function changeMonth(amount) { setMonth(m => new Date(m.getFullYear(), m.getMonth() + amount, 1)) }
  return <div className="portal-calendar" aria-label={t('calendar')}><Field label="selectDate" name="appointment-date" type="date" min={min} max={max} value={value} required onChange={e => { onChange(e.target.value); if (/^\d{4}-\d{2}-\d{2}$/.test(e.target.value)) setMonth(new Date(`${e.target.value}T12:00:00`)) }} /><div className="portal-calendar-heading"><button type="button" aria-label={t('previousMonth')} disabled={`${first.getFullYear()}-${String(first.getMonth() + 1).padStart(2, '0')}` <= min.slice(0, 7)} onClick={() => changeMonth(-1)}><ArrowLeft size={16} /></button><strong aria-live="polite">{label}</strong><button type="button" aria-label={t('nextMonth')} disabled={todayValue(first).slice(0, 7) >= max.slice(0, 7)} onClick={() => changeMonth(1)}><ArrowRight size={16} /></button></div><div className="portal-calendar-grid">{weekdays.map((day, i) => <span key={`w${i}`}>{day}</span>)}{Array.from({ length: first.getDay() }, (_, i) => <span key={`blank${i}`} />)}{Array.from({ length: days }, (_, i) => { const day = new Date(month.getFullYear(), month.getMonth(), i + 1), date = todayValue(day); return <button type="button" key={date} aria-label={new Intl.DateTimeFormat(language, { dateStyle: 'full' }).format(day)} aria-pressed={value === date} disabled={date < min || date > max || day.getDay() === 5} onClick={() => onChange(date)}>{number(i + 1)}</button> })}</div></div>
}
function Booking({ query }) {
  const { state, t, commit, navigate, setNotice, busy, date } = usePortal()
  const params = new URLSearchParams(query), existing = state.appointments.find(a => a.id === params.get('reschedule') && a.status === 'confirmed' && new Date(`${a.date}T${a.time}`) > new Date())
  const [draft, setDraft] = useState({ date: existing?.date || dateAtOffset(1), time: existing?.time || '', type: existing?.type || 'collection', orderId: existing?.orderId || (state.orders.some(o => o.id === params.get('order') && o.status !== 'cancelled') ? params.get('order') : '') }), [error, setError] = useState('')
  async function submit(e) {
    e.preventDefault()
    if (!validSlot(draft.date, draft.time, state.appointments, existing?.id) || !['collection', 'consultation'].includes(draft.type) || (draft.orderId && !state.orders.some(o => o.id === draft.orderId && o.status !== 'cancelled'))) { setError('invalidSlot'); return }
    const appointment = { ...existing, ...draft, id: existing?.id || `SAMPLE-A${crypto.randomUUID().slice(0, 8)}`, status: 'confirmed' }
    if (await commit({ type: 'APPOINTMENT', existing: existing?.id, appointment })) { navigate('appointments'); setNotice('appointmentSaved') }
  }
  if (params.has('reschedule') && !existing) return <Empty title="notFound" action="appointments" onClick={() => navigate('appointments')} />
  return <><Title title="bookTitle" hint="bookHint"><Button secondary onClick={() => navigate('appointments')}>{t('appointments')}</Button></Title><section className="portal-card"><p className="portal-info"><strong>{t('availability')}</strong> · {t('availabilityHint')}</p><form noValidate onSubmit={submit}><div className="portal-book-grid"><div><CalendarPicker value={draft.date} onChange={value => { setDraft({ ...draft, date: value, time: '' }); setError('') }} /><div className="portal-field-grid"><Field label="type" name="appointment-type" value={draft.type} onChange={e => setDraft({ ...draft, type: e.target.value })}><option value="collection">{t('collection')}</option><option value="consultation">{t('consultation')}</option></Field><Field label="relatedOrder" name="appointment-order" disabled={!!existing?.tests?.length} value={draft.orderId} onChange={e => setDraft({ ...draft, orderId: e.target.value })}><option value="">{t('none')}</option>{state.orders.filter(o => o.status !== 'cancelled').map(o => <option key={o.id} value={o.id}>{o.id}</option>)}</Field></div></div><fieldset className="portal-slots"><legend>{t('selectTime')}</legend><div>{timeSlots.map(time => <button key={time} type="button" aria-pressed={draft.time === time} disabled={!validSlot(draft.date, time, state.appointments, existing?.id) || draft.date > dateAtOffset(180)} onClick={() => { setDraft({ ...draft, time }); setError('') }}><bdi>{time}</bdi></button>)}</div></fieldset></div><div className="portal-book-summary"><h2>{t('summary')}</h2><p>{draft.date && /^\d{4}-\d{2}-\d{2}$/.test(draft.date) ? date(draft.date) : t('choose')} · <bdi>{draft.time || '—'}</bdi> · {t(draft.type)}</p></div>{error && <p className="portal-error" role="alert">{t(error)}</p>}<div className="portal-actions"><Button secondary onClick={() => navigate('appointments')}>{t('back')}</Button><Button type="submit" disabled={busy}>{t(busy ? 'saving' : existing ? 'saveReschedule' : 'confirmAppointment')}</Button></div></form></section></>
}
function ConfirmDialog({ onClose, onConfirm, busy }) {
  const { t } = usePortal(), dialog = useRef(null)
  useEffect(() => { const node = dialog.current; node.showModal(); return () => { if (node.open) node.close() } }, [])
  return <dialog ref={dialog} className="portal-dialog" aria-labelledby="cancel-title" onCancel={onClose}><h2 id="cancel-title">{t('cancelTitle')}</h2><p>{t('cancelHint')}</p><div className="portal-actions"><Button secondary autoFocus onClick={onClose}>{t('keep')}</Button><Button className="portal-button is-danger" disabled={busy} onClick={onConfirm}>{t('confirmCancel')}</Button></div></dialog>
}
function Appointments() {
  const { state, t, date, navigate, commit, busy } = usePortal(), [tab, setTab] = useState('upcoming'), [cancelId, setCancelId] = useState(null)
  const matches = state.appointments.filter(a => tab === 'upcoming' ? a.status === 'confirmed' && new Date(`${a.date}T${a.time}`) > new Date() : a.status !== 'confirmed' || new Date(`${a.date}T${a.time}`) <= new Date()).sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
  return <><Title title="appointments" hint="appointmentsHint"><Button onClick={() => navigate('book')}><Plus size={16} />{t('book')}</Button></Title><FilterTabs options={['upcoming', 'past']} value={tab} onChange={setTab} /><section className="portal-card">{matches.length ? <div className="portal-table-wrap"><table><thead><tr>{['date', 'type', 'status', 'actions'].map(k => <th key={k}>{t(k)}</th>)}</tr></thead><tbody>{matches.map(a => <tr key={a.id}><th scope="row">{date(a.date)}<small className="portal-block"><bdi>{a.time}</bdi></small></th><td>{t(a.type)}</td><td><Status value={a.status} /></td><td><VisitLink visit={visitForAppointment(state, a.id)} />{tab === 'upcoming' && <div className="portal-row-actions">{a.tests?.length > 0 && <Button secondary onClick={() => navigate(`appointments/${a.id}`)}>{t('viewBooking')}</Button>}<Button secondary onClick={() => navigate(`book?reschedule=${encodeURIComponent(a.id)}`)}>{t('reschedule')}</Button><button className="portal-cancel" onClick={() => setCancelId(a.id)}>{t('cancel')}</button></div>}</td></tr>)}</tbody></table></div> : <Empty title="noAppointments" action="book" onClick={() => navigate('book')} />}</section>{cancelId && <ConfirmDialog busy={busy} onClose={() => setCancelId(null)} onConfirm={async () => { if (await commit({ type: 'CANCEL', id: cancelId }, 'cancelledNotice')) setCancelId(null) }} />}</>
}
function Results() {
  const { state, t, local, date, navigate } = usePortal(), [search, setSearch] = useState(''), [category, setCategory] = useState('all'), [status, setStatus] = useState('all')
  const results = state.results.filter(r => { const test = state.tests.find(t => t.id === r.testId); return (status === 'all' || (status === 'availableResults' ? r.status === 'published' : r.status === 'pending')) && (category === 'all' || test.category === category) && local(test.name).toLowerCase().includes(search.trim().toLowerCase()) })
  return <><Title title="results" hint="resultsHint" /><FilterTabs options={['all', 'availableResults', 'resultsPending']} value={status} onChange={setStatus} /><div className="portal-controls"><Field label="searchResults" name="results-search" type="search" value={search} onChange={e => setSearch(e.target.value)} /><Field label="category" name="results-category" value={category} onChange={e => setCategory(e.target.value)}><option value="all">{t('allCategories')}</option>{categories.map(k => <option key={k} value={k}>{t(k)}</option>)}</Field></div><section className="portal-card">{results.length ? <div className="portal-table-wrap"><table><thead><tr>{['test', 'resultDate', 'status', 'actions'].map(k => <th key={k}>{t(k)}</th>)}</tr></thead><tbody>{results.map(r => <tr key={r.id}><th scope="row">{local(state.tests.find(t => t.id === r.testId).name)}</th><td>{date(r.date)}</td><td><Status value={r.status} /></td><td><div className="portal-row-actions"><Button secondary disabled={r.status !== 'published'} onClick={() => navigate(`results/${r.id}`)}>{t('viewResult')}</Button><ReportDownload result={r} compact /><VisitLink visit={visitForResult(state, r.id)} /></div></td></tr>)}</tbody></table></div> : <Empty onClick={() => { setSearch(''); setCategory('all'); setStatus('all') }} />}</section></>
}
function ReportDownload({ result, compact = false }) {
  const { t, setNotice, development, state, local, date } = usePortal(), [busy, setBusy] = useState(false)
  async function download() {
    setBusy(true)
    try {
      if (import.meta.env.DEV && development && isInternalRecord(result)) {
        const { downloadSampleReport } = await import('./sampleReport.js')
        await downloadSampleReport({ profile: state.profile, result, test: state.tests.find(test => test.id === result.testId), t, local, date })
        return
      }
      const blob = await portalApi.downloadReport({ resultId: result.id })
      if (!(blob instanceof Blob) || blob.type !== 'application/pdf') throw new Error('No authorized PDF')
      const url = URL.createObjectURL(blob), link = document.createElement('a')
      link.href = url; link.download = result.id + '.pdf'; link.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch { setNotice('pdfError') } finally { setBusy(false) }
  }
  return <Button secondary onClick={download} disabled={result.status !== 'published' || busy} aria-label={t('downloadPdf')}><Download size={15} />{t(busy ? 'downloading' : compact ? 'download' : 'downloadPdf')}</Button>
}
function Report({ id }) {
  const { state, t, local, date, navigate } = usePortal(), result = state.results.find(r => r.id === id && r.status === 'published')
  if (!result) return <Empty title="resultUnavailable" action="backResults" onClick={() => navigate('results')} />
  const test = state.tests.find(t => t.id === result.testId)
  return <><Title title="resultReport"><div className="portal-row-actions"><ReportDownload result={result} /><Button secondary onClick={() => window.print()}><Printer size={15} />{t('print')}</Button></div></Title><article className="portal-card portal-report"><header className="portal-report-brand"><BrandLogo /><div><strong>Smart-LIMS</strong><p>{t('resultReport')}</p></div></header><div className="portal-report-info"><dl><dt>{t('name')}</dt><dd>{state.profile.name}</dd><dt>{t('dob')}</dt><dd>{date(state.profile.dateOfBirth)}</dd><dt>{t('fileNumber')}</dt><dd><bdi>{state.profile.fileNumber}</bdi></dd></dl><dl><dt>{t('orderNumber')}</dt><dd><bdi>{result.orderId}</bdi></dd><dt>{t('sampleDate')}</dt><dd>{date(result.sampleDate)}</dd><dt>{t('resultDate')}</dt><dd>{date(result.date)}</dd></dl></div><h2>{local(test.name)}</h2><div className="portal-table-wrap"><table><thead><tr>{['test', 'result', 'unit', 'range', 'flag'].map(k => <th key={k}>{t(k)}</th>)}</tr></thead><tbody>{result.values.map((row, i) => <tr key={i}><th scope="row">{local(row.name)}</th><td><bdi>{row.value}</bdi></td><td><bdi>{row.unit}</bdi></td><td><bdi>{row.range}</bdi></td><td><Status value={row.flag} /></td></tr>)}</tbody></table></div><p className="portal-report-footnote">{t('reportHint')}</p></article><div className="portal-actions"><Button secondary onClick={() => navigate('results')}><ArrowLeft size={16} />{t('backResults')}</Button><VisitLink visit={visitForResult(state, id)} /></div></>
}
function Notifications() {
  const { state, t, datetime, navigate, dispatch } = usePortal(), [filter, setFilter] = useState('all')
  const matches = state.notifications.filter(n => filter === 'all' || (filter === 'unread' ? !n.read : n.category === filter))
  return <><Title title="notifications" hint="notificationsHint"><Button secondary disabled={!state.notifications.some(n => !n.read)} onClick={() => dispatch({ type: 'READ', id: 'all' })}><CheckCircle2 size={16} />{t('markAll')}</Button></Title><FilterTabs options={['all', 'unread', 'orders', 'results', 'appointments', 'system']} value={filter} onChange={setFilter} /><section className="portal-card portal-notifications">{matches.length ? matches.map(n => <article key={n.id} className={n.read ? '' : 'is-unread'}><span className="portal-icon">{n.category === 'results' ? <FileText size={20} /> : n.category === 'appointments' ? <CalendarDays size={20} /> : <Bell size={20} />}</span><button className="portal-notification-link" onClick={() => { dispatch({ type: 'READ', id: n.id }); navigate(n.target) }}><strong>{t(n.key)}</strong><small>{t(n.category)} · {datetime(n.date)}</small></button>{!n.read && <button className="portal-text" onClick={() => dispatch({ type: 'READ', id: n.id })}>{t('markRead')}</button>}</article>) : <Empty onClick={() => setFilter('all')} />}</section></>
}
